#include "Gate.h"



Gate::Gate()
{
	m_pFront = NULL;
	m_pRear = NULL;
	m_iCreateTimer = clock();
	CreateCar();
}

void Gate::Update()
{
	Input();
	Enqueue();
	if (m_pFront != NULL && m_pFront->DeququqCheck())
	{
		m_pFront->EraseCar();
		Dequeue();
	}
	Car* Temp = m_pFront;
	if(Temp != NULL)
		Temp->Move();
}


void Gate::Input()
{
	if (kbhit())
	{
		char ch = getch();
		if (ch == SPACE)
		{
			Car* Temp = m_pFront;
			if (Temp != NULL)
				Temp->ChangeSpeed();
		}
	}
}


void Gate::CreateCar()
{
	Car* temp = new Car;
	if (m_pFront == NULL)
	{
		m_pFront = temp;
		m_pRear = temp;
	}
	else
	{
		m_pRear->SetNext(temp);
		m_pRear = temp;
	}
	m_iCreateTimer = clock();
}
void Gate::Enqueue()
{
	char ch;
	if (clock() - m_iCreateTimer >= CREATE_TIME)
	{
		CreateCar();
	}
}

void Gate::Dequeue()
{
	if (m_pFront != NULL)
	{
		Car* temp = m_pFront;
		m_pFront = m_pFront->GetNext();
		if (m_pFront == NULL)
			m_pRear = NULL;
	}
}

Gate::~Gate()
{
}
