#include"Gate.h"

void main()
{
	Gate gate;
	while (true)
	{
		gate.Update();
	}
}