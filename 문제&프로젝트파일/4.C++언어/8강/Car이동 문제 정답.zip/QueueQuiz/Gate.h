#pragma once
#include"Car.h"
#define CREATE_TIME 5000

class Gate
{
private:
	Car* m_pFront;
	Car* m_pRear;
	int m_iCreateTimer;
public:
	void Input();
	void Enqueue();
	void Update();
	void CreateCar();
	void Dequeue();
	Gate();
	~Gate();
};

