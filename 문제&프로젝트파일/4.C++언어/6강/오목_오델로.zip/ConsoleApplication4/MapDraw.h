#pragma once
#include<iostream>
#include<Windows.h>
#include<string>
using namespace std;

class MapDraw
{
private:
	static MapDraw* m_pThis;
public:
	static MapDraw* GetInstance()
	{
		if (m_pThis == NULL)
			m_pThis = new MapDraw;
		return m_pThis;
	}
	void Erase(int x, int y, int Width, int Height);
	void BoxDraw(int Start_x,int Start_y, int Width, int Height);
	void DrawPoint(string str, int x, int y);
	void DrawMidText(string str, int x, int y);
	void Draw(int Width,int Height);
	MapDraw();
	inline void gotoxy(int x, int y)
	{
		COORD Pos = { x, y };
		SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), Pos);
	}
	~MapDraw();
};

