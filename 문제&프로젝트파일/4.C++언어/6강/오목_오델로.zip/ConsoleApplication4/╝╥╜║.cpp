#include"OmPlay.h"

void main()
{
	OmPlay Player(20,20);
	system("mode con: lines=25 cols=41");
	Player.Display();
}