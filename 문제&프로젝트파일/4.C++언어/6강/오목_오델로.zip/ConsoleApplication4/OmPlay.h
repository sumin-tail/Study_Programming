#pragma once
#include<conio.h>
#include<iomanip>
#include"MapDraw.h"
#include"Player.h"
#define LEFT 75
#define RIGHT 77
#define UP 72
#define DOWN 80
#define ESC 27
#define DROP 'z'
#define BACK 'x'
#define OPTION 'p'

enum GAME_STATE
{
	GAME_STATE_OMOK = 1,
	GAME_STATE_OTHELLO
};

struct Cursor
{
	int x;
	int y;
	string P1_Icon = "��"; 
	string P2_Icon = "��";
};

class OmPlay
{
private:
	bool		m_bPlayState;
	int			m_iWidth;
	int			m_iHeight;
	Cursor		m_Cursor;
	Player		m_P1;
	Player		m_P2;
	int			m_iTurn;
	string		m_strTeam_Name[2];
	string		m_Win_Team_Name;
	GAME_STATE	m_eGame_State;	
	void		Playing();
	void		Othello_Playing();
	void		TitleDraw();
	bool		Input();
	bool		Omok_Result();
	bool		Othello_Result();
	void		Option();
	void		ReSet();
public:
	void Display();

	OmPlay(int x,int y);
	~OmPlay();
};

