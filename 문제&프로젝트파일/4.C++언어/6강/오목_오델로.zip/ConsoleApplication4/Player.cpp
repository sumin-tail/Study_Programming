#include "Player.h"

Player::Player()
{
	m_StoneList = NULL;
	m_iReturn_Count = 5;
}

void Player::Team_Set(TEAM_STATE State)
{

	m_eTeam_State = State;
	if (State == TEAM_STATE_BLACK)
		m_strStone_State = "��";
	else if (State == TEAM_STATE_WHITE)
		m_strStone_State = "��";

	return;
}

bool Player::Compare_Stone(int x, int y)
{
	Stone* tmp = m_StoneList;

	while (tmp != NULL)
	{
		if (tmp->x == x&&tmp->y == y)
			return false;

		tmp = tmp->Next;
	}
	return true;
}


void Player::Delete_Stone(int x, int y)
{
	Stone** tmp = &m_StoneList;
	Stone* tmp2;
	while (*tmp != NULL)
	{
		if ((*tmp)->x == x && (*tmp)->y == y)
		{
			tmp2 = *tmp;
			*tmp = (*tmp)->Next;
			delete tmp2;
			return;
		}
		tmp = &(*tmp)->Next;
	}
	return;
}

void Player::Create_Stone(int x, int y)
{
	Stone* Add;
	Add = new Stone;
	Add->x = x;
	Add->y = y;
	Add->Next = NULL;		

	if (m_StoneList == NULL)
		m_StoneList = Add;
	else
	{
		Stone* tmp = m_StoneList;
		while (tmp->Next != NULL)
			tmp = tmp->Next;
		tmp->Next = Add;
	}
	return;
}


bool Player::Search_xy(int x, int y)
{
	Stone* tmp = m_StoneList;
	while (tmp != NULL)
	{
		if (tmp->x == x && tmp->y == y)
			return true;
		tmp = tmp->Next;
	}
	return false;
}

int Player::Stone_The_Number()
{
	Stone* tmp = m_StoneList;
	int count = 0;
	while (tmp != NULL)
	{
		count++;
		tmp = tmp->Next;
	}
	return count;
}

Point Player::Left_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(--x, y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}

Point Player::Right_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(++x, y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}
Point Player::Up_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(x, --y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}
Point Player::Down_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(x, ++y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}
Point Player::L_Up_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(--x, --y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}
Point Player::R_Up_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(++x, --y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}
Point Player::L_Down_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(--x, ++y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}
Point Player::R_Down_Check(int x, int y)
{
	int count = 0;
	Point tmp;
	while (Search_xy(++x, ++y))
	{
		count++;
	}
	tmp.count = count;
	tmp.x = x;
	tmp.y = y;
	return tmp;
}

bool Player::Omok_Win(int x, int y)
{
	if (m_StoneList == NULL)
		return false;
	else
	{
		if (Left_Check(x , y).count + Right_Check(x , y).count + 1 == 5)
			return true;
		else if (Up_Check(x, y).count + Down_Check(x, y).count + 1 == 5)
			return true;
		else if (L_Up_Check(x, y).count + R_Down_Check(x , y).count + 1 == 5)
			return true;
		else if (L_Down_Check(x, y).count + R_Up_Check(x, y).count + 1 == 5)
			return true;
	}
	return false;
}


bool Player::Othello_Win(int x, int y, Player* Enemy)
{
	Point tmp = Enemy->Left_Check(x, y);
	if (tmp.count && Search_xy(tmp.x,tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x - i, y);
			Create_Stone(x - i, y);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	tmp = Enemy->Right_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x + i, y);
			Create_Stone(x + i, y);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	tmp = Enemy->Up_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x, y-i);
			Create_Stone(x, y-i);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	tmp = Enemy->Down_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x, y+i);
			Create_Stone(x, y+i);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}	
	tmp = Enemy->L_Up_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x - i, y - i);
			Create_Stone(x - i, y - i);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	tmp = Enemy->R_Up_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x + i, y-i);
			Create_Stone(x + i, y-i);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	tmp = Enemy->L_Down_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x - i, y + i);
			Create_Stone(x - i, y + i);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	tmp = Enemy->R_Down_Check(x, y);
	if (tmp.count && Search_xy(tmp.x, tmp.y))
	{
		for (int i = 1; i <= tmp.count; i++)
		{
			Enemy->Delete_Stone(x + i, y + i);
			Create_Stone(x + i, y + i);
			Enemy->Stone_Draw();
			Stone_Draw();
			Sleep(300);
		}
	}
	return true;
}

void Player::Stone_Draw()
{
	Stone* tmp = m_StoneList;
	while (tmp != NULL)
	{
		MapDraw::GetInstance()->DrawPoint(m_strStone_State, tmp->x, tmp->y);
		tmp = tmp->Next;
	}
	return;
}

void Player::Release_Stone(Stone* tmp)
{
	if (tmp == NULL)
		return;
	else
		Release_Stone(tmp->Next);
	delete tmp;

	return;
}


bool Player::Stone_Backing(int Width,int Height)
{
	if (m_iReturn_Count > 0)
	{
		Stone** tmp = &m_StoneList;
		while ((*tmp)->Next != NULL)
			tmp = &(*tmp)->Next;
		MapDraw::GetInstance()->Erase((*tmp)->x, (*tmp)->y, Width, Height);
		delete *tmp;
		*tmp = NULL;
		m_iReturn_Count--;
		return true;
	}
	return false;
}
void Player::Release()
{
	Release_Stone(m_StoneList);
	m_StoneList = NULL;
	return;
}

Player::~Player()
{
	Release();
}
