#pragma once
#include<Windows.h>
#include"MapDraw.h"

enum TEAM_STATE
{
	TEAM_STATE_WHITE,
	TEAM_STATE_BLACK
};

struct Point
{
	int count;
	int x;
	int y;
};
struct Stone
{
	int x;
	int y;
	Stone* Next = NULL;
};

class Player
{
private:
	TEAM_STATE m_eTeam_State;
	Stone* m_StoneList;
	string m_strStone_State;
	int m_iReturn_Count;
	void Release_Stone(Stone* tmp);
	bool Search_xy(int x, int y);
	Point Left_Check(int x, int y);
	Point Right_Check(int x, int y);
	Point Up_Check(int x, int y);
	Point Down_Check(int x, int y);
	Point L_Up_Check(int x, int y);
	Point R_Up_Check(int x, int y);
	Point L_Down_Check(int x, int y);
	Point R_Down_Check(int x, int y);
public:
	void Release();
	int Stone_The_Number();
	bool Compare_Stone(int x, int y);
	void Create_Stone(int x,int y);
	void Delete_Stone(int x, int y);
	bool Omok_Win(int x, int y);
	bool Othello_Win(int x, int y, Player* Enemy);
	void Stone_Draw();
	void Team_Set(TEAM_STATE State);
	bool Stone_Backing(int Width, int Height);
	inline void Return_Set(int num)
	{
		m_iReturn_Count = num;
		return;
	}
	inline void SetStone(string Stone)
	{
		m_strStone_State = Stone;
		return;
	}
	inline int Get_Return_Count()
	{
		return m_iReturn_Count;
	}
	Player();
	~Player();
};

