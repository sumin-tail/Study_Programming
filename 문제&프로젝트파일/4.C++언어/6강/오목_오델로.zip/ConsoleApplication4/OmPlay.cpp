#include "OmPlay.h"



OmPlay::OmPlay(int x, int y)
{
	m_iWidth = x;
	m_iHeight = y;
	m_Cursor.x = m_iWidth / 2;
	m_Cursor.y = m_iHeight / 2;
	m_P1.Team_Set(TEAM_STATE_BLACK);
	m_P2.Team_Set(TEAM_STATE_WHITE);
	m_iTurn = 1;
	m_eGame_State = GAME_STATE_OTHELLO;
	m_bPlayState = false;
	m_strTeam_Name[0] = "White Team";
	m_strTeam_Name[1] = "Black Team";
}

void OmPlay::Option()
{
	int Select; 
	int Width,Height;
	char buf[256];
	while (1)
	{
		system("cls");
		MapDraw::GetInstance()->BoxDraw(0, 0, m_iWidth, m_iHeight);
		MapDraw::GetInstance()->DrawMidText("---��     ��---", m_iWidth, m_iHeight* 0.1);
		MapDraw::GetInstance()->DrawMidText("1.�� ������ ����", m_iWidth, (m_iHeight* 0.1) + 2);
		MapDraw::GetInstance()->DrawMidText("2.Ŀ�� Ŀ����", m_iWidth, (m_iHeight* 0.1) + 4);
		MapDraw::GetInstance()->DrawMidText("3.�� Ŀ����", m_iWidth, (m_iHeight* 0.1) + 6);
		MapDraw::GetInstance()->DrawMidText("4.���� ����", m_iWidth, (m_iHeight* 0.1) + 8);
		MapDraw::GetInstance()->DrawMidText("5.������ ����", m_iWidth, (m_iHeight* 0.1) + 10);
		MapDraw::GetInstance()->DrawMidText("6.���ư���", m_iWidth, (m_iHeight* 0.1) + 12);
		MapDraw::GetInstance()->DrawMidText("���� : ", m_iWidth, (m_iHeight* 0.1) + 14);
		cin >> Select;
		system("cls");
		MapDraw::GetInstance()->BoxDraw(0, 0, m_iWidth, m_iHeight);
		switch (Select)
		{
		case 1:
			if (!m_bPlayState)
			{
				Width = m_iWidth;
				Height = m_iHeight;
				while (1)
				{
					MapDraw::GetInstance()->DrawMidText("�� ũ�� ����", Width, Height* 0.1);
					MapDraw::GetInstance()->DrawMidText("���� : ", Width, (Height* 0.1) + 2);
					cin >> m_iWidth;
					MapDraw::GetInstance()->DrawMidText("���� : ", Width, (Height* 0.1) + 4);
					cin >> m_iHeight;
					if ((m_iHeight >= 20 && m_iHeight <= 45) && (m_iWidth >= 20 && m_iWidth <= 90))
						break;
					system("cls");
					MapDraw::GetInstance()->BoxDraw(0, 0, Width, Height);
					MapDraw::GetInstance()->DrawMidText("���� �Ұ���", Width, (Height* 0.1) + 4);
					MapDraw::GetInstance()->DrawMidText("(���� : 20 ~ 90 , ���� :20 ~ 45)", Width, (Height* 0.1) + 6);
					MapDraw::GetInstance()->gotoxy(0, Height);
					system("pause");
				}
				sprintf(buf, "mode con: lines=%d cols=%d", m_iHeight + 4, (m_iWidth * 2) + 1);
				system(buf);
				m_Cursor.x = m_iWidth / 2;
				m_Cursor.y = m_iHeight / 2;
			}
			else
			{
				MapDraw::GetInstance()->DrawMidText("Play���Դϴ�.", m_iWidth, (m_iHeight* 0.1) + 2);
				MapDraw::GetInstance()->DrawMidText("(���� ����)", m_iWidth, (m_iHeight* 0.1) + 4);
				MapDraw::GetInstance()->gotoxy(0, m_iHeight);
				system("pause");
			}
			break;
		case 2:
			MapDraw::GetInstance()->DrawMidText("1.(��,��)  2.(��,��)", m_iWidth, (m_iHeight* 0.1) + 2);
			MapDraw::GetInstance()->DrawMidText("3.(��,��) 4.(��,��) 5.��Ÿ", m_iWidth, (m_iHeight* 0.1) + 4);
			MapDraw::GetInstance()->DrawMidText("6.���ư���", m_iWidth, (m_iHeight* 0.1) + 6);
			MapDraw::GetInstance()->DrawMidText("���� : ", m_iWidth, (m_iHeight* 0.1) + 8);
			cin >> Select;
			switch (Select)
			{
			case 1:
				m_Cursor.P1_Icon = "��";
				m_Cursor.P2_Icon = "��";
				break;
			case 2:
				m_Cursor.P1_Icon = "��";
				m_Cursor.P2_Icon = "��";
				break;
			case 3:
				m_Cursor.P1_Icon = "��";
				m_Cursor.P2_Icon = "��";
				break;
			case 4:
				m_Cursor.P1_Icon = "��";
				m_Cursor.P2_Icon = "��";
				break;
			case 5:
				while (1)
				{
					system("cls");
					MapDraw::GetInstance()->BoxDraw(0, 0, m_iWidth, m_iHeight);
					MapDraw::GetInstance()->DrawMidText("P1Ŀ�� : ", m_iWidth, (m_iHeight* 0.1) + 4);
					cin >> m_Cursor.P1_Icon;
					MapDraw::GetInstance()->DrawMidText("P2Ŀ�� : ", m_iWidth, (m_iHeight* 0.1) + 6);
					cin >> m_Cursor.P2_Icon;
					if (m_Cursor.P1_Icon.size() == 2 && m_Cursor.P2_Icon.size() == 2)
						break;
					MapDraw::GetInstance()->DrawMidText("Ŀ���� Ư������ 1���� �����մϴ�.", m_iWidth, (m_iHeight* 0.1) + 8);
					system("pause");
				}
				break;
			}
			break;
		case 3:
			MapDraw::GetInstance()->DrawMidText("1.(��,��)  2.(��,��)", m_iWidth, (m_iHeight* 0.1) + 2);
			MapDraw::GetInstance()->DrawMidText("3.(��,��) 4.(��,��)", m_iWidth, (m_iHeight* 0.1) + 4);
			MapDraw::GetInstance()->DrawMidText("5.���ư���", m_iWidth, (m_iHeight* 0.1) + 6);
			MapDraw::GetInstance()->DrawMidText("���� : ", m_iWidth, (m_iHeight* 0.1) + 8);
			cin >> Select;
			switch (Select)
			{
			case 1:
				m_P1.SetStone("��");
				m_P2.SetStone("��");
				break;
			case 2:
				m_P1.SetStone("��");
				m_P2.SetStone("��");
				break;
			case 3:
				m_P1.SetStone("��");
				m_P2.SetStone("��");
				break;
			case 4:
				m_P1.SetStone("��");
				m_P2.SetStone("��");
				break;
			}
			break;
		case 4:			
			if (!m_bPlayState)
			{
				MapDraw::GetInstance()->DrawMidText("���� ����", m_iWidth, m_iHeight* 0.1);
				MapDraw::GetInstance()->DrawMidText("1.�� ��", m_iWidth, (m_iHeight* 0.1) + 2);
				MapDraw::GetInstance()->DrawMidText("2.������", m_iWidth, (m_iHeight* 0.1) + 4);
				MapDraw::GetInstance()->DrawMidText("3.���ư���", m_iWidth, (m_iHeight* 0.1) + 6);
				MapDraw::GetInstance()->DrawMidText("���� : ", m_iWidth, (m_iHeight* 0.1) + 8);
				cin >> Select;
				if (Select == GAME_STATE_OMOK)
					m_eGame_State = GAME_STATE_OMOK;
				else if (Select == GAME_STATE_OTHELLO)
					m_eGame_State = GAME_STATE_OTHELLO;
			}
			else
			{
				MapDraw::GetInstance()->DrawMidText("Play���Դϴ�.", m_iWidth, (m_iHeight* 0.1) + 2);
				MapDraw::GetInstance()->DrawMidText("(���� ����)", m_iWidth, (m_iHeight* 0.1) + 4);
				MapDraw::GetInstance()->gotoxy(0, m_iHeight);
				system("pause");
			}
			break;
		case 5:
			if (!m_bPlayState)
			{
				MapDraw::GetInstance()->DrawMidText("���� ����", m_iWidth, m_iHeight* 0.1);
				MapDraw::GetInstance()->DrawMidText("1.������ Ƚ�� ����", m_iWidth, (m_iHeight* 0.1) + 2);
				MapDraw::GetInstance()->DrawMidText("2.������ OFF", m_iWidth, (m_iHeight* 0.1) + 4);
				MapDraw::GetInstance()->DrawMidText("3.���ư���", m_iWidth, (m_iHeight* 0.1) + 6);
				MapDraw::GetInstance()->DrawMidText("���� : ", m_iWidth, (m_iHeight* 0.1) + 8);
				cin >> Select;
				switch (Select)
				{
				case 1:
					MapDraw::GetInstance()->DrawMidText("������ Ƚ�� �Է� : ", m_iWidth, (m_iHeight* 0.1) + 10);
					cin >> Select;
					m_P1.Return_Set(Select);
					m_P2.Return_Set(Select);
					break;
				case 2:
					m_P1.Return_Set(0);
					m_P2.Return_Set(0);
					break;
				}
			}
			else
			{
				MapDraw::GetInstance()->DrawMidText("Play���Դϴ�.", m_iWidth, (m_iHeight* 0.1) + 2);
				MapDraw::GetInstance()->DrawMidText("(���� ����)", m_iWidth, (m_iHeight* 0.1) + 4);	
				MapDraw::GetInstance()->gotoxy(0, m_iHeight);
				system("pause");
			}
			break;
		case 6:
			return;
		default:
			break;
		}
	}
	return;
}

void OmPlay::TitleDraw()
{
	if(m_eGame_State == GAME_STATE_OMOK)
		MapDraw::GetInstance()->DrawMidText("�ܡۿ�  ��ۡ�",m_iWidth,m_iHeight/4);
	else if(m_eGame_State == GAME_STATE_OTHELLO)
		MapDraw::GetInstance()->DrawMidText("�ܡۿ� �� �Ρۡ�", m_iWidth, m_iHeight / 4);

	MapDraw::GetInstance()->DrawMidText("1.���� ����", m_iWidth, 2+(m_iHeight / 4));
	MapDraw::GetInstance()->DrawMidText("2.���� ����", m_iWidth, 4 + (m_iHeight / 4));
	MapDraw::GetInstance()->DrawMidText("3. ����", m_iWidth, 6 + (m_iHeight / 4));
	return;
}

bool OmPlay::Input()
{
	char ch;
	char buf[256];
	bool Backing_State = false,Game_Over = false;
	ch = getch();
	MapDraw::GetInstance()->Erase(m_Cursor.x, m_Cursor.y, m_iWidth, m_iHeight);
	switch (ch)
	{
	case LEFT:
		if (m_Cursor.x - 1 >= 0)
			m_Cursor.x--;
		break;
	case RIGHT:
		if (m_Cursor.x + 1 < m_iWidth)
			m_Cursor.x++;
		break;
	case UP:
		if (m_Cursor.y - 1 >= 0)
			m_Cursor.y--;
		break;
	case DOWN:
		if (m_Cursor.y + 1 < m_iHeight)
			m_Cursor.y++;
		break;
	case DROP:
		if (m_P1.Compare_Stone(m_Cursor.x, m_Cursor.y) && m_P2.Compare_Stone(m_Cursor.x, m_Cursor.y))
		{
			if (m_iTurn % 2 == 1)
				m_P1.Create_Stone(m_Cursor.x, m_Cursor.y);
			else
				m_P2.Create_Stone(m_Cursor.x, m_Cursor.y);
			if (m_eGame_State == GAME_STATE_OMOK)
			{
				if (Omok_Result())
					Game_Over = true;
			}
			else if (m_eGame_State == GAME_STATE_OTHELLO)
			{
				if (Othello_Result())
					Game_Over = true;
			}
			if (Game_Over)
			{
				if(m_Win_Team_Name == "���º�")
					sprintf(buf, "�� �� ��");
				else
					sprintf(buf, "%s �¸�!!", m_Win_Team_Name.c_str());
				m_P1.Stone_Draw();
				m_P2.Stone_Draw();
				MapDraw::GetInstance()->DrawMidText(buf, m_iWidth, m_iHeight / 2);
				MapDraw::GetInstance()->gotoxy(0, m_iHeight);
				Sleep(2000);
				return false;
			}
			m_iTurn++;
		}
		break;
	case BACK:
		if (m_iTurn > 1)
		{
			m_iTurn--;
			if (m_iTurn % 2 == 1)
			{
				if (!m_P1.Stone_Backing(m_iWidth, m_iHeight))
					Backing_State = true;
			}
			else
			{
				if (!m_P2.Stone_Backing(m_iWidth, m_iHeight))
					Backing_State = true;
			}
			if (Backing_State)
			{
				MapDraw::GetInstance()->DrawMidText("������ Ƚ�� ����", 0, m_iHeight + 3);
				Sleep(1000);
				MapDraw::GetInstance()->DrawMidText("                 ", 0, m_iHeight + 3);
				m_iTurn++;
			}
		}
		break;
	case ESC:
		return false;
	case OPTION:
		Option();
		system("cls");
		MapDraw::GetInstance()->Draw(m_iWidth, m_iHeight);
		MapDraw::GetInstance()->gotoxy(0, m_iHeight + 1);
		cout << "�� ���� : z , ������ : x, ���� : ESC" << endl << "�ɼ� : p";
		break;
	}
	return true;
}
bool OmPlay::Othello_Result()
{
	bool Win_state = false;
	if(m_iTurn % 2 == 0)
		m_P2.Othello_Win(m_Cursor.x, m_Cursor.y, &m_P1);
	else
		m_P1.Othello_Win(m_Cursor.x, m_Cursor.y, &m_P2);
	
	int P1_Stone_Count = m_P1.Stone_The_Number();
	int P2_Stone_Count = m_P2.Stone_The_Number();
	if ((P1_Stone_Count + P2_Stone_Count) == (m_iHeight* m_iWidth))
	{
		Win_state = true;
		if (P1_Stone_Count > P2_Stone_Count)
			m_Win_Team_Name = m_strTeam_Name[1];
		else if (P1_Stone_Count < P2_Stone_Count)
			m_Win_Team_Name = m_strTeam_Name[0];
		else
			m_Win_Team_Name = "���º�";
	}
	return Win_state;

}
bool OmPlay::Omok_Result()
{
	bool Win_state = false;
	if (m_iTurn % 2 == 0)
	{
		if (m_P2.Omok_Win(m_Cursor.x, m_Cursor.y))
			Win_state = true;
	}
	else
	{
		if (m_P1.Omok_Win(m_Cursor.x, m_Cursor.y))
			Win_state = true;
	}
	if(Win_state)
		m_Win_Team_Name = m_strTeam_Name[m_iTurn % 2];
	return Win_state;
}

void OmPlay::Playing()
{
	m_bPlayState = true;
	system("cls");
	MapDraw::GetInstance()->BoxDraw(0, 0, m_iWidth, m_iHeight);
	MapDraw::GetInstance()->DrawMidText("�� �̸� ����", m_iWidth, m_iHeight* 0.1);
	MapDraw::GetInstance()->DrawMidText("P1 �̸� : ", m_iWidth, (m_iHeight* 0.1) + 2);
	cin >> m_strTeam_Name[1];
	MapDraw::GetInstance()->DrawMidText("P2 �̸� : ", m_iWidth, (m_iHeight* 0.1) + 4);
	cin >> m_strTeam_Name[0];
	system("cls");
	if (m_eGame_State == GAME_STATE_OTHELLO)
	{
		m_P1.Create_Stone(m_iWidth/2, m_iHeight/2);
		m_P1.Create_Stone((m_iWidth / 2)-1, (m_iHeight / 2)-1);
		m_P2.Create_Stone(m_iWidth / 2, (m_iHeight / 2) - 1);
		m_P2.Create_Stone((m_iWidth / 2) - 1,m_iHeight / 2);
	}
	MapDraw::GetInstance()->Draw(m_iWidth, m_iHeight);
	MapDraw::GetInstance()->gotoxy(0, m_iHeight+1);
	cout << "�� ���� : z , ������ : x, ���� : ESC"<< endl << "�ɼ� : p";
	while (1)
	{
		m_P1.Stone_Draw();
		m_P2.Stone_Draw();
		MapDraw::GetInstance()->DrawMidText("              ", m_iWidth*1.5, m_iHeight + 3);
		MapDraw::GetInstance()->DrawMidText(m_strTeam_Name[m_iTurn % 2], m_iWidth*1.5, m_iHeight + 3);
		if (m_iTurn % 2 == 0)
		{
			MapDraw::GetInstance()->DrawPoint(m_Cursor.P1_Icon, m_Cursor.x, m_Cursor.y);
			MapDraw::GetInstance()->gotoxy(0, m_iHeight+3);
			cout << "������ Ƚ�� : " << setw(2)<< left << m_P1.Get_Return_Count();
		}
		else
		{
			MapDraw::GetInstance()->DrawPoint(m_Cursor.P2_Icon, m_Cursor.x, m_Cursor.y);
			MapDraw::GetInstance()->gotoxy(0, m_iHeight + 3);
			cout << "������ Ƚ�� : " << setw(5) << left << m_P2.Get_Return_Count();
		}
		MapDraw::GetInstance()->gotoxy(0, m_iHeight);
		cout << "Turn : " << setw(10) << left << m_iTurn;
		if (!Input())
			return;
	}
	return;
}
void OmPlay::Othello_Playing()
{

}

void OmPlay::ReSet()
{
	m_P1.Release();
	m_P2.Release();
	m_Cursor.x = m_iWidth / 2;
	m_Cursor.y = m_iHeight / 2;
	m_iTurn = 1;
	m_bPlayState = false;
}

void OmPlay::Display()
{
	int Select;
	while (1)
	{
		system("cls");
		MapDraw::GetInstance()->Draw(m_iWidth,m_iHeight);
		TitleDraw();
		MapDraw::GetInstance()->BoxDraw(m_iWidth, m_iHeight - 7, 7, 3);
		MapDraw::GetInstance()->gotoxy(m_iWidth, m_iHeight - 6);
		cin >> Select;
		switch (Select)
		{
		case 1:
			Playing();
			ReSet();
			break;
		case 2:
			Option();
			break;
		case 3:
			MapDraw::GetInstance()->gotoxy(0, m_iHeight);
			return;
		}
	}
	return;
}

OmPlay::~OmPlay()
{
}
